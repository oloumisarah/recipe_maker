/*Student: Sarah Oloum
Number: 100996173
Reference: COMP2406 MONGODOB lecture
if code looks similar its cause the code from lecture was reused.*/

var express = require('express');
var app = express();
var mongo = require('mongoDB').MongoClient;
var bodyParser = require('body-parser');
const URL = "mongodb://localhost:27017/recipeDB";


app.set('views', './views');
app.set('view engine', 'pug'); //render a pug template for the main page

//from exmaple code in class
app.use(function(req, res, next) {
    console.log(req.method + " request for " + req.url);
    next();
});

app.get(['/', '/index.html', '/home', '/index'], function(req, res) {

    res.render('index.pug');

});
var db;
//Server will contain a route for handling GET requests for "/recipes".
// That route  serves a list of all recipe names presently stored in the database.
app.get('/recipes', function(req, res) { //get request for recipes
    var recipeslist = [];
    mongo.connect(URL, function(err, db) {
        if (err) {
            res.sendStatus(400);
        } else {
            var collection = db.collection("recipes");
            var cursor = collection.find();

            cursor.each(function(err, document) {
                if (err) {
                    handleset(res, err, 500, 'failed to connnect to db');
                } else if (document == null) {
                    res.send({
                        names: recipeslist
                        //recipe information should be sent as an object with the form {names: [name1, name2,....]} in order for the provided client-side code to work as expected.
                    });
                    db.close();//close connection
                } else {
                    console.log("Adding recipe name " + document.name);
                    recipeslist.push(document.name);
                }
            });
        }
    });
});

app.get("/recipe/:name", function(req, res) {
    mongo.connect(URL, function(err, db) {
        if (err) {
            res.sendStatus(400);
        } else {
          // Requests to view the recipe should be handled by first querying the database for any matching documents.
            var collection = db.collection("recipes");
            collection.findOne({
                name: req.params.name
            }, function(err, document) {
                if (document == null) {
                  //recipe does not exist in the database the server should respond with 404.
                    res.sendStatus(404);
                    console.log("error getting our recipe");
                } else {
                    res.send(document);
                }
                db.close();
            });
        }
    });
});



app.use("/recipe", bodyParser.urlencoded({
    extended: true
}));

//parse the body using body paraser.. take the data out of the body and insert it as an object
app.post("/recipe", function(req, res) {
    mongo.connect(URL, function(err, db) {
        var collection = db.collection("recipes"); // anything that starts with a colon gets put in req.params
        //insert in to it
        //to insert that specific object you need the query string
        //collection.insertOne(req.query, function(err, result) { //you can use insertMany

        if(req.body.name !== null){
          collection.update({name:req.body.name}, req.body, {upsert:true} ,function(err,result){
            //The handler for POST requests to "/recipe" should insert the recipe object into the database,
            //and respond with an appropriate status code: 200 (OK) if the recipe was added successfully,
            //500 (server error) if the database failed to insert the recipe, and 400 (bad request) if the POST'ed recipe object contains no name
            //(ie. if the name is an empty string).
      			if(err){
              console.log(err);
      				handleset(res, err, 500, 'The database failed to insert the recipe...');
            }
      			else{
      				res.sendStatus(200);
              console.log("The recipe was added successfully!");
            }
      			db.close();
      		});
        }
        else{
          res.sendStatus(400);
          console.log("POST'ed recipe object contains no name...");
        }
      });
    });

app.use(express.static("./public")); //handle all static requests

app.all("*", function(req, res) {
    res.sendStatus(404);
});
app.listen(2406, function() { //Server listens to port 2406
    console.log('Server listening on port 2406');
});
