Name: Sarah Oloumi
Student Number:100996173
Reference:
  COMP2406 lecture notes for mongoDB and pug
  mongo + pug + express APIs

Instructions:
1) Type in node server.js
2) Type in "localhost:2406" in browser url
3) Enter a recipe's information *** Make sure there are no empty recipes + names dont have the new line character
4) Click submit
5) to view existing recipe you click the "Recipe" drop down and click on one then click view.
